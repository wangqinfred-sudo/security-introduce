const fs = require('fs');
const path = require('path');

// 要修复的HTML文件列表
const htmlFiles = [
    'data-protection-detail.html',
    'access-security-detail.html',
    'account-security-detail.html',
    'log-audit-detail.html',
    'member-permissions-detail.html',
    'terminal-security-detail.html'
];

// 修复单个HTML文件的函数
function fixHtmlFile(filePath) {
    console.log(`正在修复文件: ${filePath}`);
    
    // 读取文件内容
    let content = fs.readFileSync(filePath, 'utf8');
    
    // 1. 替换箭头函数为function语法
    content = content.replace(/setTimeout\(\(\) => {/g, 'setTimeout(function() {');
    content = content.replace(/setInterval\(\(\) => {/g, 'setInterval(function() {');
    
    // 2. 替换const/let为var
    content = content.replace(/const\s+/g, 'var ');
    content = content.replace(/let\s+/g, 'var ');
    
    // 3. 替换模板字符串为普通字符串拼接
    content = content.replace(/tempCard\.innerHTML = `([\s\S]*?)`;/g, (match, innerHTML) => {
        // 转义双引号
        const escapedHtml = innerHTML.replace(/"/g, '\\"');
        // 替换换行符
        const singleLineHtml = escapedHtml.replace(/\n/g, '');
        // 替换${}变量为字符串拼接
        const finalHtml = singleLineHtml.replace(/\$\{([^}]*)\}/g, "' + $1 + '");
        return `tempCard.innerHTML = '${finalHtml}';`;
    });
    
    // 4. 替换可选链操作符
    content = content.replace(/document\.querySelector\('([^']*)'\)\?\./g, (match, selector) => {
        return `(function(el) { return el ? el. : null; })(document.querySelector('${selector}'))`;
    });
    
    // 更安全的可选链替换方式
    content = content.replace(/(document\.querySelector\([^)]*\))\?\.style\./g, (match, query) => {
        return `(function(el) { return el ? el.style. : null; })(${query})`;
    });
    
    // 修复addEventListener中的箭头函数
    content = content.replace(/document\.addEventListener\('DOMContentLoaded', \(\) => {/g, 'document.addEventListener(\'DOMContentLoaded\', function() {');
    
    // 修复forEach中的箭头函数
    content = content.replace(/forEach\(([^)]*) => {/g, 'forEach(function($1) {');
    
    // 修复addEventListener中的箭头函数
    content = content.replace(/addEventListener\('click', \(\) => {/g, "addEventListener('click', function() {");
    
    // 5. 修复getQueryParam函数
    const getQueryParamFix = `// 从URL中获取查询参数
        function getQueryParam(name) {
            try {
                var url = window.location.href;
                var paramValue = null;
                var startIndex = url.indexOf('?' + name + '=');
                if (startIndex === -1) {
                    startIndex = url.indexOf('&' + name + '=');
                }
                if (startIndex !== -1) {
                    startIndex += name.length + 2;
                    var endIndex = url.indexOf('&', startIndex);
                    if (endIndex === -1) {
                        endIndex = url.length;
                    }
                    paramValue = decodeURIComponent(url.substring(startIndex, endIndex));
                }
                return paramValue;
            } catch (error) {
                console.error('getQueryParam函数错误:', error);
                return null;
            }
        }`;
    
    // 替换getQueryParam函数
    content = content.replace(/\/\/ 从URL中获取查询参数[\s\S]*?}\s*}/, getQueryParamFix);
    
    // 写入修复后的内容
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`文件修复完成: ${filePath}`);
}

// 遍历所有HTML文件并修复
htmlFiles.forEach(file => {
    const filePath = path.join(__dirname, file);
    if (fs.existsSync(filePath)) {
        fixHtmlFile(filePath);
    } else {
        console.log(`文件不存在: ${filePath}`);
    }
});

console.log('所有文件修复完成!');