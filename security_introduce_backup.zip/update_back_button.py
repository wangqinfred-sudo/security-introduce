import os
import re

def update_back_button(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 更新返回按钮的onclick事件，使用单引号避免HTML语法错误
        updated_content = re.sub(
            r'<button\s+class="back-arrow"[^>]*onclick="window\.history\.back\(\)"[^>]*>',
            '<button class="back-arrow" onclick="window.location.href=\'http://localhost:8000/\'" title="返回安全功能总览">',
            content
        )
        
        if updated_content != content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)
            print(f"Updated: {file_path}")
        else:
            print(f"No change needed: {file_path}")
    except Exception as e:
        print(f"Error processing {file_path}: {e}")

def main():
    directory = "/Users/bytedance/Documents/trae_projects/security introduce"
    
    for filename in os.listdir(directory):
        if filename.endswith('.html'):
            file_path = os.path.join(directory, filename)
            update_back_button(file_path)
    
    print("All HTML files have been processed.")

if __name__ == "__main__":
    main()