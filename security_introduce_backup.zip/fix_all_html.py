import os
import re

# 要修复的HTML文件列表
html_files = [
    'data-protection-detail.html',
    'access-security-detail.html',
    'account-security-detail.html',
    'log-audit-detail.html',
    'member-permissions-detail.html',
    'terminal-security-detail.html'
]

def fix_html_file(file_path):
    print(f"正在修复文件: {file_path}")
    
    # 读取文件内容
    with open(file_path, 'r', encoding='utf8') as f:
        content = f.read()
    
    # 1. 替换箭头函数为function语法
    content = re.sub(r'setTimeout\(\(\) => {', 'setTimeout(function() {', content)
    content = re.sub(r'setInterval\(\(\) => {', 'setInterval(function() {', content)
    
    # 2. 替换const/let为var
    content = re.sub(r'const\s+', 'var ', content)
    content = re.sub(r'let\s+', 'var ', content)
    
    # 3. 替换addEventListener中的箭头函数
    content = re.sub(r'document\.addEventListener\(\'DOMContentLoaded\', \(\) => {', 
                   "document.addEventListener('DOMContentLoaded', function() {", content)
    
    content = re.sub(r'addEventListener\(\'click\', \(\) => {', 
                   "addEventListener('click', function() {", content)
    
    # 4. 替换forEach中的箭头函数
    content = re.sub(r'forEach\(([^)]*) => {', 'forEach(function(\1) {', content)
    
    # 5. 修复可选链操作符 - 这部分需要更复杂的处理
    # 我们将使用更安全的方式来替换
    def replace_optional_chain(match):
        query = match.group(1)
        return f"(function(el) {{ return el ? el. : null; }})({query})"
    
    content = re.sub(r'(document\.querySelector\([^)]*\))\?\.', replace_optional_chain, content)
    
    # 6. 修复getQueryParam函数
    get_query_param_fix = '''// 从URL中获取查询参数
        function getQueryParam(name) {
            try {
                var url = window.location.href;
                var paramValue = null;
                var startIndex = url.indexOf('?' + name + '=');
                if (startIndex === -1) {
                    startIndex = url.indexOf('&' + name + '=');
                }
                if (startIndex !== -1) {
                    startIndex += name.length + 2;
                    var endIndex = url.indexOf('&', startIndex);
                    if (endIndex === -1) {
                        endIndex = url.length;
                    }
                    paramValue = decodeURIComponent(url.substring(startIndex, endIndex));
                }
                return paramValue;
            } catch (error) {
                console.error('getQueryParam函数错误:', error);
                return null;
            }
        }'''
    
    content = re.sub(r'// 从URL中获取查询参数[\s\S]*?}\s*}', get_query_param_fix, content)
    
    # 7. 修复模板字符串
    def replace_template_string(match):
        inner_html = match.group(1)
        # 转义双引号
        escaped_html = inner_html.replace('"', '\\"')
        # 替换换行符
        single_line_html = escaped_html.replace('\n', '')
        # 替换${}变量为字符串拼接
        final_html = re.sub(r'\$\{([^}]*)\}', "' + \1 +  '", single_line_html)
        return f"tempCard.innerHTML = '{final_html}';"
    
    content = re.sub(r'tempCard\.innerHTML = `([\s\S]*?)`;', replace_template_string, content)
    
    # 写入修复后的内容
    with open(file_path, 'w', encoding='utf8') as f:
        f.write(content)
    
    print(f"文件修复完成: {file_path}")

# 遍历所有HTML文件并修复
for file_name in html_files:
    file_path = os.path.join(os.getcwd(), file_name)
    if os.path.exists(file_path):
        fix_html_file(file_path)
    else:
        print(f"文件不存在: {file_path}")

print("所有文件修复完成!")