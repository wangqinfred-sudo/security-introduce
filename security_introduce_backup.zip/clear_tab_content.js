const fs = require('fs');
const path = require('path');

// 获取当前目录下的所有HTML文件
const directoryPath = process.cwd();
fs.readdir(directoryPath, function(err, files) {
    if (err) {
        return console.log('Unable to scan directory: ' + err);
    }
    
    // 筛选出HTML文件
    const htmlFiles = files.filter(file => path.extname(file) === '.html');
    
    // 处理每个HTML文件
    htmlFiles.forEach(file => {
        const filePath = path.join(directoryPath, file);
        
        // 读取文件内容
        fs.readFile(filePath, 'utf8', function(err, data) {
            if (err) {
                return console.log('Error reading file ' + filePath + ': ' + err);
            }
            
            // 使用正则表达式匹配并清空所有.tab-content-inner元素的内容
            // 匹配模式：<div class="tab-content-inner">...</div>，不包括两步验证相关的特殊内容
            const updatedContent = data.replace(/<div class="tab-content-inner">[\s\S]*?<\/div>/g, function(match) {
                // 如果包含step-description-employee或step-description-admin，保留内容
                if (match.includes('step-description-employee') || match.includes('step-description-admin')) {
                    return match;
                }
                // 否则清空内容
                return '<div class="tab-content-inner"></div>';
            });
            
            // 写入更新后的内容
            fs.writeFile(filePath, updatedContent, 'utf8', function(err) {
                if (err) {
                    return console.log('Error writing file ' + filePath + ': ' + err);
                }
                console.log('Successfully updated ' + filePath);
            });
        });
    });
});