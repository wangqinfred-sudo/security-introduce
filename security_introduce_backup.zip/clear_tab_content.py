import os
import re

# 获取当前目录
directory_path = os.getcwd()

# 遍历当前目录下的所有文件
for filename in os.listdir(directory_path):
    # 检查是否为HTML文件
    if filename.endswith('.html'):
        file_path = os.path.join(directory_path, filename)
        
        try:
            # 读取文件内容
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # 使用正则表达式匹配并清空所有.tab-content-inner元素的内容
            # 不包括两步验证相关的特殊内容
            def replace_tab_content(match):
                if 'step-description-employee' in match.group(0) or 'step-description-admin' in match.group(0):
                    return match.group(0)
                return '<div class="tab-content-inner"></div>'
            
            updated_content = re.sub(r'<div class="tab-content-inner">[\s\S]*?<\/div>', replace_tab_content, content)
            
            # 写入更新后的内容
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(updated_content)
            
            print(f'Successfully updated {filename}')
            
        except Exception as e:
            print(f'Error processing {filename}: {str(e)}')

print('\nAll HTML files have been processed.')