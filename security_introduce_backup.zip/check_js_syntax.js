const fs = require('fs');
const path = require('path');

// 读取HTML文件
const htmlContent = fs.readFileSync('data-protection-detail.html', 'utf8');

// 提取所有JavaScript代码块
const scriptRegex = /<script>([\s\S]*?)<\/script>/g;
let match;
let scriptBlocks = [];

while ((match = scriptRegex.exec(htmlContent)) !== null) {
  scriptBlocks.push(match[1]);
}

// 检查每个JavaScript代码块是否有语法错误
scriptBlocks.forEach((script, index) => {
  console.log(`\n检查第 ${index + 1} 个script块:`);
  try {
    // 使用Node.js的vm模块来检查语法错误
    require('vm').createScript(script);
    console.log('✓ 没有语法错误');
  } catch (error) {
    console.log('✗ 发现语法错误:', error.message);
    console.log('错误位置:', error.stack.split('\n')[1]);
    
    // 输出错误所在的代码行
    const lines = script.split('\n');
    const errorLine = error.stack.split(':')[2];
    if (errorLine) {
      const lineNumber = parseInt(errorLine);
      console.log(`错误代码行 (${lineNumber}): ${lines[lineNumber - 1]}`);
    }
  }
});