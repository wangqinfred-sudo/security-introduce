import re
import os

# 要检查的HTML文件
html_files = ['data-protection-detail.html']

# 寻找可能导致语法错误的模式
patterns_to_check = [
    r'\b\d+\s*=',  # 数字赋值，如：123 = 456
    r'"[^"]*"\s*=',  # 字符串赋值，如："string" = "value"
    r'\[[^\]]*\]\s*=',  # 数组字面量赋值，如：[1,2,3] = [4,5,6]
    r'\{[^\}]*\}\s*=',  # 对象字面量赋值，如：{key: value} = {key: newValue}
    r'\([^\)]*\)\s*=',  # 括号表达式赋值，如：(a+b) = c
]

for html_file in html_files:
    print(f"\n检查文件: {html_file}")
    
    # 读取HTML文件
    with open(html_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取所有script标签内容
    script_tags = re.findall(r'<script>([\s\S]*?)</script>', content)
    
    for i, script_content in enumerate(script_tags):
        print(f"\n  检查第 {i+1} 个script块:")
        
        # 检查每个模式
        for pattern in patterns_to_check:
            matches = re.finditer(pattern, script_content)
            for match in matches:
                line_number = script_content[:match.start()].count('\n') + 1
                line_content = script_content.split('\n')[line_number-1].strip()
                print(f"    行 {line_number}: 找到可能的语法错误模式: {match.group()}")
                print(f"    行内容: {line_content}")

print("\n检查完成!")