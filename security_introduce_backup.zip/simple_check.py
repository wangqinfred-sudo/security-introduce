import re
import os

# 要检查的HTML文件
html_files = [f for f in os.listdir('.') if f.endswith('.html')]

# 检查的错误模式
error_patterns = [
    r'\x01',  # 特殊字符
    r'\`[^`]*\`',  # 模板字符串
    r'=>',  # 箭头函数
    r'const\s+|let\s+',  # const/let 声明
    r'\?\.',  # 可选链操作符
    r'\(function\(el\)\s*\{\s*return\s+el\s*\?\s*el\.\s*:\s*null;\s*\}\)\([^)]*\)style\.',  # 错误的可选链替换
]

for html_file in html_files:
    print(f"\n检查文件: {html_file}")
    
    # 读取HTML文件
    with open(html_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    has_error = False
    for pattern in error_patterns:
        matches = re.finditer(pattern, content)
        for match in matches:
            line_number = content[:match.start()].count('\n') + 1
            print(f"  行 {line_number}: 找到错误模式: {match.group()[:50]}...")
            has_error = True
    
    if not has_error:
        print(f"  ✓ 未发现语法错误模式")

print("\n检查完成!")